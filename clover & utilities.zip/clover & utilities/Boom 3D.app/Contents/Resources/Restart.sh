#!/bin/sh
sudo shutdown -r now

